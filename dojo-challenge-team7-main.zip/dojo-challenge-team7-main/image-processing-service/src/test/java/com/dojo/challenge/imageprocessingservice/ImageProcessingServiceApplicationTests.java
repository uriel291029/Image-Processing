package com.dojo.challenge.imageprocessingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageProcessingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
